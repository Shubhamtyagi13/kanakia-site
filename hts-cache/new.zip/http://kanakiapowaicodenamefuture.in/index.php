









<!DOCTYPE html>
<html>

<head>
    <!-- Google Tag Manager -->
    <script>
    (function(w, d, s, l, i) {
        w[l] = w[l] || [];
        w[l].push({
            'gtm.start': new Date().getTime(),
            event: 'gtm.js'
        });
        var f = d.getElementsByTagName(s)[0],
            j = d.createElement(s),
            dl = l != 'dataLayer' ? '&l=' + l : '';
        j.async = true;
        j.src =
            'https://www.googletagmanager.com/gtm.js?id=' + i + dl;
        f.parentNode.insertBefore(j, f);
    })(window, document, 'script', 'dataLayer', 'GTM-5XMSKDH');
    </script>
    <!-- End Google Tag Manager -->
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Codename Future Kanakia</title>
    <meta name="keywords" content="">
    <meta name="">
    <link rel="icon" href="images/favicon.png" type="image/png" sizes="16x16">
    <link href="https://fonts.googleapis.com/css?family=Montserrat:400,600,800,900" rel="stylesheet">
    <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet"
        integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN" crossorigin="anonymous">

    <link href="css/bootstrap.min.css" rel="stylesheet" type="text/css">
    <link href="css/bootstrap-theme.min.css" rel="stylesheet" type="text/css">
    <link href="css/style.css?v=1.0" rel="stylesheet" type="text/css">
    <link href="lightbox/light-box.css" rel='stylesheet' type='text/css'>

    <link rel="stylesheet" href="css/animate.min.css">

    <link rel="stylesheet" href="css/amenities.css">

    <link rel="stylesheet" href="owlcarousel/owl.carousel.min.css">
    <link rel="stylesheet" href="owlcarousel/owl.theme.default.min.css">


</head>

<body>
    <!-- Google Tag Manager (noscript) -->
    <noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-5XMSKDH" height="0" width="0"
            style="display:none;visibility:hidden"></iframe></noscript>
    <!-- End Google Tag Manager (noscript) -->
    <header id="home">
        <nav class="navbar navbar-default" id="hide-menu">
            <div class="container">
                <!-- Brand and toggle get grouped for better mobile display -->
                <div class="col-md-2">
                    <div class="navbar-header">
                        <button type="button" class="navbar-toggle collapsed" data-toggle="collapse"
                            data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
                            <span class="sr-only">Toggle navigation</span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                        </button>
                        <a class="navbar-brand" href="index.php">
                            <img src="images/logo.png">
                            <img src="images/bharat-logo.png" class="hidden-md hidden-lg">

                        </a>
                    </div>
                </div>
                <div class="col-md-8">
                    <!-- Collect the nav links, forms, and other content for toggling -->
                    <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">

                        <ul class="nav navbar-nav ">
                            <li><a href="#home" class="m-link">Home</a></li>
                            <li><a href="#aboutus" class="m-link">About Us</a></li>
                            <li><a href="#configuration" class="m-link">Configuration</a></li>
                            <li><a href="#amenities" class="m-link">Amenities</a></li>
                            <li><a href="#gallery" class="m-link">Gallery</a></li>
                            <li><a href="#location" class="m-link">Location</a></li>
                            <li><a href="#contactus" class="m-link">Contact Us</a></li>
                            <!--<li>
                        <a href="tel:18002671200" class="nav-call">
                            <span class="glyphicon glyphicon-phone" aria-hidden="true"></span>
                            1800-267-1200
                        </a>
                    </li>-->
                            <!--<li class="dropdown">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Dropdown <span class="caret"></span></a>
                        <ul class="dropdown-menu">
                            <li><a href="#">Action</a></li>
                            <li><a href="#">Another action</a></li>
                            <li><a href="#">Something else here</a></li>
                            <li role="separator" class="divider"></li>
                            <li><a href="#">Separated link</a></li>
                        </ul>
                    </li>-->
                        </ul>

                    </div>

                </div><!-- /.navbar-collapse -->
                <div class="col-md-2 hidden-xs">
                    <a class="navbar-brand" hrefh="index.php">

                        <img src="images/bharat-logo.png">
                    </a>
                </div>
            </div><!-- /.container-fluid -->
        </nav>
    </header>

    <div id="carousel-example-generic" class="carousel slide carousel-fade" data-ride="carousel">
        <ol class="carousel-indicators">
            <li data-target="#carousel-example-generic" data-slide-to="0" class="active"></li>
            <li data-target="#carousel-example-generic" data-slide-to="1" class=""></li>
            <!-- <li data-target="#carousel-example-generic" data-slide-to="2" class=""></li>
        <li data-target="#carousel-example-generic" data-slide-to="2" class=""></li> -->
        </ol>
        <div class="carousel-inner" role="listbox">
            <!-- <div class="item ">
                <img src="images/slider/slide-4.jpg" alt="" class="hidden-xs">
                <img src="images/slider/mobile-4.jpg" alt="" class="visible-xs">
            </div> -->

            <div class="item active">
                <img src="images/slider/slide-1.jpg" alt="" class="hidden-xs">
                <img src="images/slider/mobile-1.jpg" alt="" class="visible-xs">
            </div>
            <div class="item">
                <img src="images/slider/slide-2.jpg" alt="" class="hidden-xs">
                <img src="images/slider/mobile-2.jpg" alt="" class="visible-xs">
            </div>
            <!-- <div class="item">
                <img src="images/slider/slide-3.jpg" alt="" class="hidden-xs">
                <img src="images/slider/mobile-3.jpg" alt="" class="visible-xs">
            </div> -->

        </div>



        <a class="left carousel-control" href="#carousel-example-generic" role="button" data-slide="prev">
            <span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span>
            <span class="sr-only">Previous</span>
        </a>
        <a class="right carousel-control" href="#carousel-example-generic" role="button" data-slide="next">
            <span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>
            <span class="sr-only">Next</span>
        </a>
    </div>

    <section class="glob-sec lightpink-bg" id="aboutus">
        <div class="container">
            <h2 class="sec-head head-center">Overview</h2>
            <div class="head-line"><img src="images/box-dot.png"></div>

            <div class="txt-wrap">
                <h6 class="sub-head" style="text-align: center;">
                    Codename Future by Kanakia Group is a pivotal development of culture, technology and environment
                    spread across approx. 8 acres.
                </h6>
                <p style="text-align: center;">
                    An equilibrium for the modern cosmopolitan and their family, our elevated location sits right in the
                    heart of Mumbai’s most sought-after residential destination, offering stunning views
                </p>
                <!-- <p style="text-align: center;">
                    A well-planned infrastructure makes Powai significantly advanced compared to other prime locations
                    of
                    the
                    city.
                </p> -->
            </div>


        </div>
    </section>

    <section class="glob-sec imgbg1" id="configuration">
        <div class="container">
            <div class="col-md-4">
                <div class="highlight-wrap">
                    <img src="images/blueprint.png">
                    <h2><span>Approx 8 Acres</span> Of Development</h2>
                </div>
            </div>

            <div class="col-md-4">
                <div class="highlight-wrap">
                    <img src="images/handshake.png">
                    <h2><span>Futuristic</span> Approach</h2>
                </div>
            </div>

            <div class="col-md-4">
                <div class="highlight-wrap">
                    <img src="images/cityscape.png">
                    <h2><span>International</span> Design</h2>
                </div>
            </div>

            <div style="width: 100%;display: -webkit-box;height: 100px;" class="row"></div>
            <h2 class="sec-head head-center white">Project Configuration</h2>
            <div class="head-line"><img src="images/box-dot-wight.png"></div>
            <div style="width: 100%;display: -webkit-box;height: 50px;" class="row"></div>


        </div>
    </section>


    <section class="cust-sec lightpink-bg">
        <div class="container">
            <div class="config-wrap">
                <div class="col-md-8 col-md-offset-2 col-xs-12">
                    <div class="col-md-6">
                        <div class="config-box">
                            <div class="box-thinborder">
                                <h2>
                                    2 Bed<br>Residence
                                </h2>
                                <a href="javascript:void(0);" class="click-price">Click For Price</a>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="config-box">
                            <div class="box-thinborder">
                                <h2>
                                    3 Bed<br>Residence
                                </h2>
                                <a href="javascript:void(0);" class="click-price">Click For Price</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>


    <section class="glob-sec lightpink-bg" id="amenities">
        <div class="container">
            <h2 class="sec-head head-center">Project Amenities</h2>
            <div class="head-line"><img src="images/box-dot.png"></div>


            <div id="amenities-slider" class="owl-carousel owl-theme full-next-prev owl-loaded owl-drag">
                <div class="owl-stage-outer">
                    <div class="owl-stage"
                        style="transform: translate3d(0px, 0px, 0px); transition: 0s; width: 2480px;">
                        <div class="owl-item active" style="width: 373.333px; margin-right: 40px;">
                            <div class="item">
                                <img src="images/key/Fountain-View_Edit_1.jpg" alt="Volleyball">
                                <!-- <h3>Volleyball</h3> -->
                                <span>Amphitheatre</span>
                            </div>
                        </div>
                        <div class="owl-item active" style="width: 373.333px; margin-right: 40px;">
                            <div class="item">
                                <img src="images/key/Pool _View_Edit_2.jpg" alt="Volleyball">
                                <!-- <h3>Volleyball</h3> -->
                                <span>Swimming Pool</span>
                            </div>
                        </div>
                        <div class="owl-item active" style="width: 373.333px; margin-right: 40px;">
                            <div class="item">
                                <img src="images/key/AquaGym.jpg" alt="Volleyball">
                                <!-- <h3>Volleyball</h3> -->
                                <span>Aqua Gym</span>
                            </div>
                        </div>
                        <div class="owl-item active" style="width: 373.333px; margin-right: 40px;">
                            <div class="item">
                                <img src="images/key/FitnessCentre.jpg" alt="Spa">
                                <!-- <h3>Spa</h3> -->
                                <span>Fitness Centre</span>
                            </div>
                        </div>
                        <div class="owl-item active" style="width: 373.333px; margin-right: 40px;">
                            <div class="item">
                                <img src="images/key/HalfBasketballcourt.jpg" alt="Kids Play Area">
                                <!-- <h3>Kids Play Area</h3> -->
                                <span>Half Basketball court</span>
                            </div>
                        </div>
                        <div class="owl-item active" style="width: 373.333px; margin-right: 40px;">
                            <div class="item">
                                <img src="images/key/IndoorGames.jpg" alt="Gymnasium">
                                <!-- <h3>Gymnasium</h3> -->
                                <span>Indoor Games</span>
                            </div>
                        </div>
                        <div class="owl-item" style="width: 373.333px; margin-right: 40px;">
                            <div class="item">
                                <img src="images/key/Jacuzzi.jpg" alt="Badminton">
                                <!-- <h3>Football</h3> -->
                                <span>Jacuzzi</span>
                            </div>
                        </div>
                        <div class="owl-item" style="width: 373.333px; margin-right: 40px;">
                            <div class="item">
                                <img src="images/key/Jogging-Area.jpg" alt="Banquet Hall">
                                <!-- <h3>Banquet Hall</h3> -->
                                <span>Jogging Area</span>
                            </div>
                        </div>
                        <div class="owl-item" style="width: 373.333px; margin-right: 40px;">
                            <div class="item">
                                <img src="images/key/Kids-Pool.jpg" alt="yoga">
                                <!-- <h3>Banquet Hall</h3> -->
                                <span>Kids Pool</span>
                            </div>
                        </div>
                        <div class="owl-item" style="width: 373.333px; margin-right: 40px;">
                            <div class="item">
                                <img src="images/key/TennisCourt.jpg" alt="Badminton">
                                <!-- <h3>Banquet Hall</h3> -->
                                <span>Tennis Court</span>
                            </div>
                        </div>
                        <div class="owl-item" style="width: 373.333px; margin-right: 40px;">
                            <div class="item">
                                <img src="images/key/YogaArea.jpg" alt="gym">
                                <!-- <h3>Banquet Hall</h3> -->
                                <span>Yoga Area</span>
                            </div>
                        </div>
                    </div>
                </div>

            </div>


        </div>
    </section>


    <section class="glob-sec garkpink" id="gallery">
        <div class="container">
            <h2 class="sec-head head-center">Project Gallery</h2>
            <div class="head-line"><img src="images/box-dot.png"></div>

            <div class="txt-wrap">
                <p style="text-align: center;">
                    Codename Future by Kanakia Group is a pivotal development of culture, technology and environment
                    spread across approx. 8 acres..
                </p>
            </div>

            <div style="width: 100%;height: 50px;"></div>

            <div class="gall-wrap">


                <!-- Nav tabs -->
                <ul class="nav nav-tabs mytab" role="tablist">
                    <li role="presentation" class="active">
                        <a href="#general" aria-controls="profile" role="tab" data-toggle="tab"
                            aria-expanded="true">General
                        </a>
                    </li>
                    <li role="presentation" class="">
                        <a href="#floorplan" aria-controls="settings" role="tab" data-toggle="tab"
                            aria-expanded="false">Floor Plan
                        </a>
                    </li>
                    <li role="presentation" class="">
                        <a href="#masterplan" aria-controls="settings" role="tab" data-toggle="tab"
                            aria-expanded="false">Master Layout
                        </a>
                    </li>
                </ul>

                <!-- Tab panes -->
                <div class="tab-content delay-09s animated wow fadeInUp animated"
                    style="visibility: visible; animation-name: fadeInDown;">

                    <!-- ======================================== -->
                    <div role="tabpanel" class="tab-pane fade active in" id="general">
                        <div class="tab-content-wrap">

                            <div class="latest-post col-md-6">
                                <div class="latest-post" style="background-image: url(images/gallery/general/1.jpg);">
                                    <div class="latest-post-inner match-height l-box">
                                        <span class="link-icon">
                                            <a href="images/gallery/general/1.jpg">
                                                <i class="fa fa-chain"></i>
                                            </a>
                                        </span>
                                    </div>
                                </div>
                            </div>

                            <div class="latest-post col-md-6">
                                <div class="latest-post" style="background-image: url(images/gallery/general/2.jpg);">
                                    <div class="latest-post-inner match-height l-box">
                                        <span class="link-icon">
                                            <a href="images/gallery/general/2.jpg">
                                                <i class="fa fa-chain"></i>
                                            </a>
                                        </span>
                                    </div>
                                </div>
                            </div>

                            <!-- <div class="latest-post col-md-4">
                            <div class="latest-post" style="background-image: url(images/gallery/general/3.jpg);">
                                <div class="latest-post-inner match-height l-box">
                                   <span class="link-icon">
                                      <a href="images/gallery/general/3.jpg">
                                          <i class="fa fa-chain"></i>
                                      </a>
                                   </span>
                                </div>
                            </div>
                        </div> -->


                        </div>
                    </div>

                    <!-- ========================================= -->
                    <div role="tabpanel" class="tab-pane fade" id="floorplan">
                        <div class="tab-content-wrap">

                            <div class="col-md-3">
                                <div class="latest-post gall-box">
                                    <div class="latest-post gall-box"
                                        style="background-image: url(images/gallery/plan/2.jpg);">
                                        <div class="latest-post-inner match-height l-box">
                                            <span class="link-icon">
                                                <a href="images/gallery/plan/2.jpg">
                                                    <i class="fa fa-chain"></i>
                                                </a>
                                            </span>
                                        </div>
                                    </div>
                                </div>
                                <p class="gall-txt">2 BHK<br>Rera Carpet Area: 563 SQFT</p>
                            </div>

                            <div class="col-md-3">
                                <div class="latest-post gall-box">
                                    <div class="latest-post gall-box"
                                        style="background-image: url(images/gallery/plan/3.jpg);">
                                        <div class="latest-post-inner match-height l-box">
                                            <span class="link-icon">
                                                <a href="images/gallery/plan/3.jpg">
                                                    <i class="fa fa-chain"></i>
                                                </a>
                                            </span>
                                        </div>
                                    </div>
                                </div>
                                <p class="gall-txt">2 BHK<br>Rera Carpet Area: 613 SQFT</p>
                            </div>


                            <div class="col-md-3">
                                <div class="latest-post gall-box">
                                    <div class="latest-post gall-box"
                                        style="background-image: url(images/gallery/plan/4.jpg);">
                                        <div class="latest-post-inner match-height l-box">
                                            <span class="link-icon">
                                                <a href="images/gallery/plan/4.jpg">
                                                    <i class="fa fa-chain"></i>
                                                </a>
                                            </span>
                                        </div>
                                    </div>
                                </div>
                                <p class="gall-txt">2 BHK<br>Rera Carpet Area: 652 SQFT</p>
                            </div>

                            <div class="col-md-3">
                                <div class="latest-post gall-box">
                                    <div class="latest-post gall-box"
                                        style="background-image: url(images/gallery/plan/5.jpg);">
                                        <div class="latest-post-inner match-height l-box">
                                            <span class="link-icon">
                                                <a href="images/gallery/plan/5.jpg">
                                                    <i class="fa fa-chain"></i>
                                                </a>
                                            </span>
                                        </div>
                                    </div>
                                </div>
                                <p class="gall-txt">2 BHK<br>Rera Carpet Area: 671 SQFT</p>
                            </div>

                            <div class="col-md-3">
                                <div class="latest-post gall-box">
                                    <div class="latest-post gall-box"
                                        style="background-image: url(images/gallery/plan/6.jpg);">
                                        <div class="latest-post-inner match-height l-box">
                                            <span class="link-icon">
                                                <a href="images/gallery/plan/6.jpg">
                                                    <i class="fa fa-chain"></i>
                                                </a>
                                            </span>
                                        </div>
                                    </div>
                                </div>
                                <p class="gall-txt">2 BHK<br>Rera Carpet Area: 718 SQFT</p>
                            </div>

                            <div class="col-md-3">
                                <div class="latest-post gall-box">
                                    <div class="latest-post gall-box"
                                        style="background-image: url(images/gallery/plan/7.jpg);">
                                        <div class="latest-post-inner match-height l-box">
                                            <span class="link-icon">
                                                <a href="images/gallery/plan/7.jpg">
                                                    <i class="fa fa-chain"></i>
                                                </a>
                                            </span>
                                        </div>
                                    </div>
                                </div>
                                <p class="gall-txt">2 BHK<br>Rera Carpet Area: 752 SQFT</p>
                            </div>

                            <div class="col-md-3">
                                <div class="latest-post gall-box">
                                    <div class="latest-post gall-box"
                                        style="background-image: url(images/gallery/plan/8.jpg);">
                                        <div class="latest-post-inner match-height l-box">
                                            <span class="link-icon">
                                                <a href="images/gallery/plan/8.jpg">
                                                    <i class="fa fa-chain"></i>
                                                </a>
                                            </span>
                                        </div>
                                    </div>
                                </div>
                                <p class="gall-txt">2 BHK<br>Rera Carpet Area: 758 SQFT</p>
                            </div>

                            <div class="col-md-3">
                                <div class="latest-post gall-box">
                                    <div class="latest-post gall-box"
                                        style="background-image: url(images/gallery/plan/9.jpg);">
                                        <div class="latest-post-inner match-height l-box">
                                            <span class="link-icon">
                                                <a href="images/gallery/plan/9.jpg">
                                                    <i class="fa fa-chain"></i>
                                                </a>
                                            </span>
                                        </div>
                                    </div>
                                </div>
                                <p class="gall-txt">2 BHK<br>Rera Carpet Area: 760 SQFT</p>
                            </div>

                            <div class="col-md-3">
                                <div class="latest-post gall-box">
                                    <div class="latest-post gall-box"
                                        style="background-image: url(images/gallery/plan/10.jpg);">
                                        <div class="latest-post-inner match-height l-box">
                                            <span class="link-icon">
                                                <a href="images/gallery/plan/10.jpg">
                                                    <i class="fa fa-chain"></i>
                                                </a>
                                            </span>
                                        </div>
                                    </div>
                                </div>
                                <p class="gall-txt">2 BHK<br>Rera Carpet Area: 769 SQFT</p>
                            </div>

                            <div class="col-md-3">
                                <div class="latest-post gall-box">
                                    <div class="latest-post gall-box"
                                        style="background-image: url(images/gallery/plan/11.jpg);">
                                        <div class="latest-post-inner match-height l-box">
                                            <span class="link-icon">
                                                <a href="images/gallery/plan/11.jpg">
                                                    <i class="fa fa-chain"></i>
                                                </a>
                                            </span>
                                        </div>
                                    </div>
                                </div>
                                <p class="gall-txt">3 BHK<br>Rera Carpet Area: 967 SQFT</p>
                            </div>

                            <!-- <div class="col-md-3">
                                <div class="latest-post gall-box">
                                    <div class="latest-post gall-box"
                                        style="background-image: url(images/gallery/plan/12.jpg);">
                                        <div class="latest-post-inner match-height l-box">
                                            <span class="link-icon">
                                                <a href="images/gallery/plan/12.jpg">
                                                    <i class="fa fa-chain"></i>
                                                </a>
                                            </span>
                                        </div>
                                    </div>
                                </div>
                                <p class="gall-txt">3 BHK<br>Rera Carpet Area: 975 SQFT</p>
                            </div>

                            <div class="col-md-3">
                                <div class="latest-post gall-box">
                                    <div class="latest-post gall-box"
                                        style="background-image: url(images/gallery/plan/13.jpg);">
                                        <div class="latest-post-inner match-height l-box">
                                            <span class="link-icon">
                                                <a href="images/gallery/plan/13.jpg">
                                                    <i class="fa fa-chain"></i>
                                                </a>
                                            </span>
                                        </div>
                                    </div>
                                </div>
                                <p class="gall-txt">3 BHK<br>Rera Carpet Area: 1350 SQFT</p>
                            </div> -->

                        </div>
                    </div>

                    <!-- ======================================== -->
                    <div role="tabpanel" class="tab-pane fade" id="masterplan">
                        <div class="tab-content-wrap">

                            <div class="col-md-4 col-md-offset-4">
                                <div class="latest-post">
                                    <div class="latest-post"
                                        style="background-image: url(images/gallery/Master-plan.jpg);">
                                        <div class="latest-post-inner match-height l-box">
                                            <span class="link-icon">
                                                <a href="images/gallery/Master-plan.jpg">
                                                    <i class="fa fa-chain"></i>
                                                </a>
                                            </span>
                                        </div>
                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>

                    <!-- ========================================= -->


                </div>


            </div>


        </div>
    </section>


    <section class="glob-sec lightpink-bg" id="location">
        <div class="container">
            <h2 class="sec-head head-center">Project Location</h2>
            <div class="head-line"><img src="images/box-dot.png"></div>
            <!-- <p class="sub-head-small" style="text-align: center;">
            Codename Future by Kanakia Group is a
            pivotal development of culture, technology
            and environment, bringing you homes of the
            future for a New India. An equilibrium for
            the modern cosmopolitan and their family. A
            head above the rest, our elevated location
            sits right in the heart of Mumbai’s most
            sought after residential district, offering
            stunning views across Powai Lake.<br>
            A well planned infrastructure makes Powai
            significantly advanced compared to other
            prime locations of the city.
        </p> -->


            <div class="loc-wrap">
                <!-- Nav tabs -->
                <ul class="nav nav-tabs mytab" role="tablist">
                    <li role="presentation" class="active">
                        <a href="#physical" aria-controls="profile" role="tab" data-toggle="tab"
                            aria-expanded="true">Connectivity
                        </a>
                    </li>
                    <li role="presentation" class="">
                        <a href="#social" aria-controls="settings" role="tab" data-toggle="tab"
                            aria-expanded="false">Social Infra
                        </a>
                    </li>
                </ul>

                <!-- Tab panes -->
                <div class="tab-content delay-09s animated wow fadeInUp animated"
                    style="visibility: visible; animation-name: fadeInDown;">

                    <!-- ======================================== -->
                    <div role="tabpanel" class="tab-pane fade active in" id="physical">
                        <div class="tab-content-wrap">

                            <div class="col-md-3 col-xs-6">
                                <div class="ami-iconholder">
                                    <img src="images/aminities/departure.png" alt="">
                                    <p>Airport</p>
                                </div>
                            </div>

                            <div class="col-md-3 col-xs-6">
                                <div class="ami-iconholder">
                                    <img src="images/aminities/train.png" alt="">
                                    <p>Kanjurmarg Railway Station,
                                        Vikhroli Railway Station</p>
                                </div>
                            </div>

                            <div class="col-md-3 col-xs-6">
                                <div class="ami-iconholder">
                                    <img src="images/aminities/metro.png" alt="">
                                    <p>Sakinaka Metro,
                                        Asalpha Metro</p>
                                </div>
                            </div>

                            <div class="col-md-3 col-xs-6">
                                <div class="ami-iconholder">
                                    <img src="images/aminities/highway.png" alt="">
                                    <p>W.E. Highway,
                                        E.E. Highway,
                                        JVLR,
                                        LBS Road</p>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- ======================================== -->
                    <div role="tabpanel" class="tab-pane fade" id="social">
                        <div class="tab-content-wrap">
                            <div class="col-md-3 col-xs-6">
                                <div class="ami-iconholder">
                                    <img src="images/aminities/hospital-sign.png" alt="">
                                    <p>Godrej Memorial Hospital,
                                        Seven Hills Hospital</p>
                                </div>
                            </div>

                            <div class="col-md-3 col-xs-6">
                                <div class="ami-iconholder">
                                    <img src="images/aminities/graduation-hat.png" alt="">
                                    <p>Podar International School,
                                        S.M. Shetty School,
                                        Bombay Scottish School</p>
                                </div>
                            </div>


                            <div class="col-md-3 col-xs-6">
                                <div class="ami-iconholder">
                                    <img src="images/aminities/hotel.png" alt="">
                                    <p>Kensington Business Park,
                                        Central Avenue,
                                        SEEPZ</p>
                                </div>
                            </div>

                            <div class="col-md-3 col-xs-6">
                                <div class="ami-iconholder">
                                    <img src="images/aminities/doorknob.png" alt="">
                                    <p>Renaissance Hotel,
                                        The Beatle,
                                        Lakeside Chalet – Marriott Hotel</p>
                                </div>
                            </div>

                            <div class="col-md-3 col-xs-6">
                                <div class="ami-iconholder">
                                    <img src="images/aminities/shopping-cart.png" alt="">
                                    <p>DMart,
                                        Powai Galleria,
                                        Powai Plaza</p>
                                </div>
                            </div>

                            <div class="col-md-3 col-xs-6">
                                <div class="ami-iconholder">
                                    <img src="images/aminities/bumper-car.png" alt="">
                                    <p>Hakone Entertainment Centrel</p>
                                </div>
                            </div>

                            <div class="col-md-3 col-xs-12">
                                <div class="ami-iconholder">
                                    <img src="images/aminities/dish.png" alt="">
                                    <p>Indigo Delicatessen,
                                        Breeze,
                                        Hoppipola,
                                        Rodas,
                                        Pizza Express,
                                        Chilli’s American Grill & Bar,
                                        Mehman Nawazi,
                                        Starbucks</p>
                                </div>
                            </div>

                        </div>
                    </div>

                </div>

            </div>


            <img src="images/map-l.jpg" class="location-map">

            <a href="https://www.google.co.in/maps/place/Kanakia+Codename+Future/@19.119668,72.9198782,15z/data=!4m5!3m4!1s0x0:0xa4e954e71740e16f!8m2!3d19.119668!4d72.9198782"
                target="_blank" class="map-click">Google Map View</a>
        </div><!-- End container -->
    </section>

    <section class="glob-sec garkpink" id="location">
        <div class="container">
            <h2 class="sec-head head-center">About Kanakia</h2>
            <div class="head-line"><img src="images/box-dot.png"></div>

            <div class="txt-wrap">
                <h6 class="sub-head" style="text-align: center;">
                    Kanakia Group was formed in the year 1986. Today Kanakia Group has earned a distinct reputation as
                    one
                    of Mumbai's premium developers.
                </h6>
                <p style="text-align: center;">
                    Kanakia has developed over 14.6 million sq. ft. of commercial, residential, entertainment, education
                    and
                    industrial spaces. Kanakia has been honored with several prestigious awards for their landmark
                    projects.
                </p>
            </div>


            <div class="col-lg-3 col-md-3 col-sm-3 wow fadeInUp" data-wow-duration="1s" data-wow-delay="0.2s">
                <div class="counter-holder">
                    <div class="numcount">
                        <h3 class="numtext"><span class="counter">41</span></h3>
                    </div>
                    <h4>RESIDENTIAL PROJECTS</h4>
                </div>
            </div>

            <div class="col-lg-3 col-md-3 col-sm-3 wow fadeInUp" data-wow-duration="1s" data-wow-delay="0.4s">
                <div class="counter-holder">
                    <div class="numcount">
                        <h3 class="numtext"><span class="counter">32</span></h3>
                    </div>
                    <h4>YEARS OF EXPERIENCE</h4>
                </div>
            </div>

            <div class="col-lg-3 col-md-3 col-sm-3 wow fadeInUp" data-wow-duration="1s" data-wow-delay="0.6s">
                <div class="counter-holder">
                    <div class="numcount">
                        <h3 class="numtext"><span class="counter">14.6</span></h3>
                    </div>
                    <h4>MILLION SQ.FT DELIVERED</h4>
                </div>
            </div>


            <div class="col-lg-3 col-md-3 col-sm-3 wow fadeInUp" data-wow-duration="1s" data-wow-delay="0.8s">
                <div class="counter-holder">
                    <div class="numcount">
                        <h3 class="numtext"><span class="counter">13</span></h3>
                    </div>
                    <h4>COMMERCIAL PROJECTS</h4>
                </div>
            </div>


            <div class="col-lg-3 col-md-3 col-sm-3 wow fadeInUp" data-wow-duration="1s" data-wow-delay="0.8s">
                <div class="counter-holder">
                    <div class="numcount">
                        <h3 class="numtext"><span class="counter">4</span></h3>
                    </div>
                    <h4>MALLS</h4>
                </div>
            </div>


            <div class="col-lg-3 col-md-3 col-sm-3 wow fadeInUp" data-wow-duration="1s" data-wow-delay="0.8s">
                <div class="counter-holder">
                    <div class="numcount">
                        <h3 class="numtext"><span class="counter">6</span></h3>
                    </div>
                    <h4>SCHOOLS</h4>
                </div>
            </div>

            <div class="col-lg-3 col-md-3 col-sm-3 wow fadeInUp" data-wow-duration="1s" data-wow-delay="0.8s">
                <div class="counter-holder">
                    <div class="numcount">
                        <h3 class="numtext"><span class="counter">141</span></h3>
                    </div>
                    <h4>SCREENS DEVELOPED</h4>
                </div>
            </div>

            <div class="col-lg-3 col-md-3 col-sm-3 wow fadeInUp" data-wow-duration="1s" data-wow-delay="0.8s">
                <div class="counter-holder">
                    <div class="numcount">
                        <h3 class="numtext"><span class="counter">3</span></h3>
                    </div>
                    <h4>HOTELS</h4>
                </div>
            </div>


        </div>
    </section>


    <section class="glob-sec imgbg1" id="contactus">
        <div class="container">
            <h2 class="sec-head head-center white">Contact Us</h2>
            <div class="head-line"><img src="images/box-dot-wight.png"></div>
            <div style="width: 100%;height: 25px;"></div>


            <div class="col-md-12">
                <div class="form-wrap">
                    <form id="contact-form" action="thank-you.php" name="contact-form" method="POST"
                        onsubmit="return save_landing_pageinfo('contact-form');" novalidate="novalidate">

                        <div class="form-group col-md-6">
                            <div class="input-group">
                                <div class="input-group-addon">
                                    <i class="fa fa-user form-ico" aria-hidden="true"></i>
                                </div>
                                <input type="text" class="form-control" name="fname" placeholder="First Name">
                            </div>
                            <label for="fname" generated="true" class="error"></label>
                        </div>

                        <div class="form-group col-md-6">
                            <div class="input-group">
                                <div class="input-group-addon">
                                    <i class="fa fa-user form-ico" aria-hidden="true"></i>
                                </div>
                                <input type="text" class="form-control" name="lname" placeholder="Last Name">
                            </div>
                            <label for="lname" generated="true" class="error"></label>
                        </div>

                        <div class="form-group col-md-6">
                            <div class="input-group">
                                <div class="input-group-addon">
                                    <i class="fa fa-mobile form-ico" aria-hidden="true"></i>
                                </div>
                                <input type="number" class="form-control" name="mobile" placeholder="Mobile">
                            </div>
                            <label for="mobile" generated="true" class="error"></label>
                        </div>
                        <div class="form-group col-md-6">
                            <div class="input-group">
                                <div class="input-group-addon">
                                    <i class="fa fa-envelope" aria-hidden="true"></i>
                                </div>
                                <input type="email" class="form-control" name="email" placeholder="Email">
                                <input type="hidden" name="source" value="Enquiry Form">
                            </div>
                            <label for="email" generated="true" class="error"></label>
                        </div>
                        <!--<div class="form-group col-md-12" style="height: initial;">
                        <div class="input-group">
                            <div class="input-group-addon"><i class="fa fa-commenting" aria-hidden="true"></i></div>
                            <textarea class="form-control" rows="3" name="message"
                                      placeholder="Your Message"></textarea>
                            <input type="hidden" name="source" value="Enquiry Form" id="source">
                        </div>
                    </div>-->
                        <button type="submit" class="btn btn-default form-btn">Submit
                        </button>

                    </form>
                </div>

            </div>


            <div class="col-md-12">
                <div class="address-wrap">
                    <h3>Site Address</h3>
                    <p>
                        Codename Future by Kanakia, CTS No. 101, Behind Dr L.H. Hiranandani Hospital, Tirandaz,<br>
                        Powai, Mumbai, Maharashtra 400076

                    </p>
                    <!--<a href="tel:18002671200" class="call-me">1800-267-1200</a>-->
                    <a href="tel:+917428384216" class="call-me">7428384216</a>
                </div>

                <!--<div class="rera-wrap">
                <img src="images/maha-rera.png" class="rera">
                <h2 class="rera-txt">MahaRERA Registration No. 0000000000</h2>
            </div>-->
            </div>


        </div>
    </section>


    <!--<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d15079.416113664794!2d72.82416112305296!3d19.1140586331899!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3be7c9c34e1585bb%3A0x8ce4216e331c5189!2sJuhu+Vikrant+Building!5e0!3m2!1sen!2sin!4v1539783378101"
    width="100%" height="450" frameborder="0" style="border:0" allowfullscreen></iframe>-->


    <section class="rera-sec">
        <div class="cust-container">
            <div class="col-md-2 footer-icon">
                <img class="img-fluid" src="images/maha-rera.png" alt="">
            </div>
            <div class="col-md-10">
                <p class="footer-text">
                    MahaRERA Registration no. for Codename Future – A: P51800018007 | Codename Future – B: P51800018113
                    |
                    Codename Future – C: P51800018008 | Codename Future – D: P51800017413 details are available on the
                    website <a href="https://maharera.mahaonline.gov.in">https://maharera.mahaonline.gov.in</a>
                </p>

                <p class="footer-text" style="font-size: 13px;">
                    Disclaimer: Kanakia Pixel is the name of Tower C of the Whole Project. Tower C is registered with
                    MahaRera as Codename Future C. The photographs, images, amenities, features, drawings, sketches,
                    renderings, elevation, pictorial, graphical representations, specifications, illustrations, other
                    information etc. contained in these material are for pure imagination/inspiration and does not
                    represent
                    what will come in the Project and are intended to indicate a conceptual and aspirational lifestyle.
                    None
                    of the aforementioned are indicative of how the Whole Project or any part thereof looks at present
                    and/or may eventually look in future and/or may be designed, constructed and/or completed. These
                    printed
                    material does not constitute an offer and / or contract of any type between the developer and the
                    recipient. Any purchaser of these development shall be governed by the terms and conditions of the
                    agreement for sale entered into between the parties and no details mentioned in these printed
                    material
                    shall in any way govern such transaction. The Project is mortgaged in favour of IDBI Trusteeship
                    Services Limited for funding by Piramal Capital & Housing Finance Limited and the buyer will be
                    required
                    to obtain a no objection certificate prior to entering in to Agreement for Sale of any unit/flat in
                    the
                    project.
                </p>
                <p>*The Subvention Scheme is available at additional interest cost to be borne by the buyer. The Date of
                    expiration of Subvention Period is 31.12.2021, on completion of which the buyer shall be liable to
                    pay PreEMI/ EMI as the case may be. T&C apply.</p>
            </div>
        </div>
    </section>


    <section class="footer-sec grey-bg" id="footer">
        <div class="container">
            <div class="foote-wrap">
                <img src="images/logo.png">
                <!--<ul class="partner">
                <li><img src="images/logo.png"></li>
                <li><img src="images/bharat-logo.png"></li>
            </ul>-->


                <p>&copy; 2019 Kanakia Group. Official Website. All rights reserved.</p>
            </div>
        </div>
    </section>
    <!-- 
    <section class="footer-sec grey-bg" id="footer">
        <div class="container">
            <div class="foote-wrap text-center">
                <h4 style="color:" class="hidden-xs"> Managed and Marketed By

                    <a href="http://realatte.com/" target="_blank" style="color: ;">Realatte
                        Ventures</a>
                </h4>

                <h4 style="color:" class="visible-xs"> Managed and Marketed By<br>

                    <a href="http://realatte.com/" target="_blank" style="color: ;">Realatte
                        Ventures</a>
                </h4>
            </div>
        </div>
    </section> -->


    <div class="col-lg-12 col-sm-12 col-xs-12 fixed-footer-cust hidden-md hidden-lg hidden-sm">
        <div class="container">
            <div class="col-lg-6 col-sm-6 col-xs-6 div-line pd0">
                <a href="tel:+917428384216" class="fix-link callme"><i class="fa fa-phone f-icon" aria-hidden="true"></i>
                    CALL NOW</a>
            </div>
            <div class="col-lg-6 col-sm-6 col-xs-6 pd0">
                <button class="btn fix-link i-am"><i class="fa fa-envelope"></i> ENQUIRE NOW</button>
            </div>
        </div>
    </div>


    <div id="pageloader">
        <img src="images/loader1.gif" alt="processing..." />
    </div>

    <!-- ================ main popup ==================== -->


    <div class="modal fade in" tabindex="-1" role="dialog" id="main-pop" data-backdrop="static" data-keyboard="false">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span
                            aria-hidden="true">×</span></button>

                    <h4 class="modal-title">Enquire Now</h4>
                </div>
                <div class="modal-body">
                    <p>Please Enter Your Details To Know More About Codename Future</p>
                    <form id="main-popup" action="thank-you.php" name="main-popup" method="POST" novalidate="novalidate"
                        onsubmit="return save_landing_pageinfo('main-popup');">
                        <div class="form-group col-md-12">
                            <div class="input-group">
                                <div class="input-group-addon">
                                    <i class="fa fa-user form-ico" aria-hidden="true"></i>
                                </div>
                                <input type="text" class="form-control" name="fname" placeholder="Name">
                                <input type="hidden" name="source" value="Main PopUp">
                            </div>
                            <label for="fname" generated="true" class="error"></label>
                        </div>
                        <div class="form-group col-md-12">
                            <div class="input-group">
                                <div class="input-group-addon">
                                    <i class="fa fa-mobile form-ico" aria-hidden="true"></i>
                                </div>
                                <input type="number" class="form-control" name="mobile" placeholder="Mobile">
                            </div>
                            <label for="mobile" generated="true" class="error"></label>
                            <!--<input type="tel" placeholder="Phone*" name="mobile" class="validate" id="contctform-phone"
                               required>
                        <span class="hide valid-msg">✓ Valid</span>
                        <span class="hide error-msg">Invalid number</span>
                        <input type="hidden" name="country_code" value="" id="calling_code">-->
                        </div>
                        <!--<div class="form-group col-md-12">
                        <div class="input-group">
                            <div class="input-group-addon">
                                <i class="fa fa-envelope" aria-hidden="true"></i>
                            </div>
                            <input type="email" class="form-control" name="email" placeholder="Email">
                        </div>
                        <label for="email" generated="true" class="error"></label>
                    </div>-->
                        <button type="submit" class="btn btn-default price-btn hvr-sweep-to-right">SUBMIT</button>
                    </form>


                </div>
            </div><!-- /.modal-content -->
        </div><!-- /.modal-dialog -->
    </div>

    <!-- ============================================= -->


    <!-- ================ price popup ==================== -->


    <div class="modal fade in" tabindex="-1" role="dialog" id="price-model" data-backdrop="static"
        data-keyboard="false">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span
                            aria-hidden="true">×</span></button>

                    <h4 class="modal-title">Pricing Information</h4>
                </div>
                <div class="modal-body">
                    <p>Please Enter Your Details To Get Pricing Information</p>
                    <form id="price-popup" action="thank-you.php" name="price-popup" method="POST"
                        novalidate="novalidate" onsubmit="return save_landing_pageinfo('price-popup');">
                        <div class="form-group col-md-12">
                            <div class="input-group">
                                <div class="input-group-addon">
                                    <i class="fa fa-user form-ico" aria-hidden="true"></i>
                                </div>
                                <input type="text" class="form-control" name="fname" placeholder="Name">
                                <input type="hidden" name="source" value="Price PopUp">
                            </div>
                            <label for="fname" generated="true" class="error"></label>
                        </div>
                        <div class="form-group col-md-12">
                            <div class="input-group">
                                <div class="input-group-addon">
                                    <i class="fa fa-mobile form-ico" aria-hidden="true"></i>
                                </div>
                                <input type="number" class="form-control" name="mobile" placeholder="Mobile">
                            </div>
                            <label for="mobile" generated="true" class="error"></label>
                        </div>
                        <!--<div class="form-group col-md-12">
                        <div class="input-group">
                            <div class="input-group-addon">
                                <i class="fa fa-envelope" aria-hidden="true"></i>
                            </div>
                            <input type="email" class="form-control" name="email" placeholder="Email">
                        </div>
                        <label for="email" generated="true" class="error"></label>
                    </div>-->
                        <button type="submit" class="btn btn-default price-btn hvr-sweep-to-right">SUBMIT</button>
                    </form>
                </div>
            </div><!-- /.modal-content -->
        </div><!-- /.modal-dialog -->
    </div>

    <!-- ============================================= -->

    <button class="btn btn-danger interested hidden-xs">Enquire Now</button>
    <!-- ================ i am ==================== -->
    <div class="modal fade in" tabindex="-1" role="dialog" id="interested" data-backdrop="static" data-keyboard="false">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">×</span>
                    </button>
                    <h4 class="modal-title">Enquire Now</h4>
                </div>
                <div class="modal-body">
                    <p>Please Enter Your Details To Know More About Codename Future </p>
                    <form id="float-form" action="thank-you.php" name="price-popup" method="POST"
                        novalidate="novalidate" onsubmit="return save_landing_pageinfo('float-form');">
                        <div class="form-group col-md-12">
                            <div class="input-group">
                                <div class="input-group-addon">
                                    <i class="fa fa-user form-ico" aria-hidden="true"></i>
                                </div>
                                <input type="text" class="form-control" name="fname" placeholder="Name">
                                <input type="hidden" name="source" value="Im Interested">
                            </div>
                            <label for="fname" generated="true" class="error"></label>
                        </div>

                        <div class="form-group col-md-12">
                            <div class="input-group">
                                <div class="input-group-addon">
                                    <i class="fa fa-mobile form-ico" aria-hidden="true"></i>
                                </div>
                                <input type="number" class="form-control" name="mobile" placeholder="Mobile">
                            </div>
                            <label for="mobile" generated="true" class="error"></label>
                            <!--<input type="tel" placeholder="Phone*" name="mobile" class="validate" id="contctform-phone4"
                               required>
                        <span class="hide valid-msg">✓ Valid</span>
                        <span class="hide error-msg">Invalid number</span>
                        <input type="hidden" name="country_code" value="" id="calling_code4">-->
                        </div>

                        <!-- <div class="form-group col-md-12">
                            <div class="input-group">
                                <div class="input-group-addon">
                                    <i class="fa fa-envelope" aria-hidden="true"></i>
                                </div>
                                <input type="email" class="form-control" name="email" placeholder="Email">
                            </div>
                            <label for="email" generated="true" class="error"></label>
                        </div> -->
                        <button type="submit" class="btn btn-default price-btn hvr-sweep-to-right">SUBMIT</button>
                    </form>

                </div>
            </div><!-- /.modal-content -->
        </div><!-- /.modal-dialog -->
    </div>

    <!-- ============================================= -->


    <script src="js/jquery-3.3.1.min.js"></script>
    <script type="text/javascript" src="lightbox/light-box.js"></script>
    <script src="js/bootstrap.min.js" type="text/javascript"></script>
    <script src="owlcarousel/owl.carousel.min.js"></script>
    <script src="js/jquery.counterup.min.js"></script>
    <script src="js/waypoints.min.js"></script>
    <script src="js/wow.js"></script>

    <script src="js/jquery.validate.js"></script>
    <script src="js/mobilevalidate.js"></script>
    <script src="js/cookie.js"></script>
    <script src="js/popout.js"></script>


    <script>
    jQuery(document).ready(function($) {
        $('.counter').counterUp({
            delay: 30,
            time: 1000
        });
    });
    </script>
    <script>
    new WOW().init();
    </script>

    <script>
    $(document).ready(function() {
        jQuery('#amenities-slider').owlCarousel({
            stagePadding: 0,
            loop: true,
            nav: true,
            margin: 40,
            autoplay: true,
            autoplayTimeout: 5000,
            autoplayHoverPause: false,
            dots: false,
            navText: ["<", ">"],
            items: 3,
            responsive: {
                0: {
                    items: 1
                },
                576: {
                    items: 2
                },
                1000: {
                    items: 3
                }
            }
        });
    });
    </script>

    <!--<script>
    // When the user scrolls down 20px from the top of the document, slide down the navbar
    window.onscroll = function () {
        scrollFunction()
    };

    function scrollFunction() {
        if (document.body.scrollTop > 20 || document.documentElement.scrollTop > 20) {
            document.getElementById("hide-menu").style.top = "0";
        } else {
            document.getElementById("hide-menu").style.top = "-60px";
        }
    }
</script>-->
    <script>
    jQuery(document).ready(function($) {
        var $floor = $('.f-box a').simpleLightbox();
        var $gallery = $('.l-box a').simpleLightbox();
    });
    </script>

    <script type="text/javascript">
    jQuery(document).ready(function($) {
        Delete_Cookie('formfilled');
        // ---------------for model only-----
        $(".click-price").click(function() {
            $('#price-model').modal('show');
        });

        $(".interested").click(function() {
            $('#interested').modal('show');
        });
        $(".i-am").click(function() {
            $('#interested').modal('show');
        });

    });
    </script>

    <script>
    jQuery(document).ready(function($) {
        // Add smooth scrolling to all links
        $(".m-link").on('click', function(event) {

            // Make sure this.hash has a value before overriding default behavior
            if (this.hash !== "") {
                // Prevent default anchor click behavior
                event.preventDefault();

                // Store hash
                var hash = this.hash;

                // Using jQuery's animate() method to add smooth page scroll
                // The optional number (800) specifies the number of milliseconds it takes to scroll to the specified area

                $('html, body').animate({
                    scrollTop: $(hash).offset().top
                }, 800, function() {
                    // Add hash (#) to URL when done scrolling (default click behavior)
                    // window.location.hash = hash;
                });
            } // End if
        });

        $('.navbar-nav li').on('click', function() {
            $('.navbar-nav li.active').removeClass('active');
            $(this).addClass('active');
        });
        $(document).on('click', '.navbar-collapse.in', function(e) {
            if ($(e.target).is('a') && ($(e.target).attr('class') != 'dropdown-toggle')) {
                $(this).collapse('hide');
            }
        });
    });
    </script>


    <script type="text/javascript">
    function save_landing_pageinfo(elm) {
        jQuery('#' + elm + ' input[type=submit], #' + elm + ' button').prop('disabled', true);
        setTimeout(function() {
            jQuery('#' + elm + ' input[type=submit], #' + elm + ' button').prop('disabled', false);
        }, 5000);
        var name = jQuery('#' + elm + ' input[name="fname"]').val();
        var mobileno = jQuery('#' + elm + ' input[name="mobile"]').val();
        var emailid = jQuery('#' + elm + ' input[name="email"]').val();
        var message = jQuery('#' + elm + ' textarea[name="message"]').val();
        var fsource = jQuery('#' + elm + ' input[name="source"]').val();
        var current_url = location.hostname;

        if (name == "") {
            //alert("Please Enter Your Name");
            return false;
        }


        mobileno = mobileno.replace(/[^0-9]/g, '');
        if (mobileno.length != 10) {
            //alert("Please Enter 10 Digit Mobile Number");
            return false;
        }


        if (elm == 'price-popup') {
            emailid = "";
        } else if (elm == 'main-popup') {
            emailid = "";
        } else {
            var atpos = emailid.indexOf("@");
            var dotpos = emailid.lastIndexOf(".");
            if (atpos < 1 || dotpos < atpos + 2 || dotpos + 2 >= emailid.length) {
                return false;
            }
        }

        if (message == undefined) {
            message = "";
        }

        if (name != "" && mobileno != "") {
            $("#pageloader").fadeIn();
            var tags = 'Codenamefuture Kanakia';
            var webToLeadData = {
                'firstname': name,
                'email': emailid,
                'mobile': mobileno,
                'tags': tags,
                'cstm_fsource': fsource,
                'cstm_current_url': current_url,
                'cstm_query': message
            };


            MTI.webToLead(webToLeadData,
                function() {
                    submitForm(elm);

                },
                function(respone) {
                    //console.log("There was an error saving the lead to the marketing automation system. ");
                    console.log(respone);
                    submitForm(elm);
                }
            );
        }
        return false;
    }

    function submitForm(elm) {
        document.createElement('form').submit.call(document.getElementById(elm));
    }
    </script>

    <script src="http://kanakia.realatte.com/mtcwtl.js"></script>

    <!-- <script>
    (function(w, d, t, u, n, a, m) {
        w['MauticTrackingObject'] = n;
        w[n] = w[n] || function() {
                (w[n].q = w[n].q || []).push(arguments)
            }, a = d.createElement(t),
            m = d.getElementsByTagName(t)[0];
        a.async = 1;
        a.src = u;
        m.parentNode.insertBefore(a, m)
    })(window, document, 'script', 'http://kanakia.realatte.com/mtc.js', 'mt');

    mt('send', 'pageview');
</script> -->

</body>

</html>